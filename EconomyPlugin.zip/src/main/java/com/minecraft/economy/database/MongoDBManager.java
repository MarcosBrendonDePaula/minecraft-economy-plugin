package com.minecraft.economy.database;

import com.minecraft.economy.core.EconomyPlugin;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

public class MongoDBManager {

    private final EconomyPlugin plugin;
    private MongoClient mongoClient;
    private MongoDatabase database;
    
    // Coleções
    private MongoCollection<Document> playersCollection;
    private MongoCollection<Document> transactionsCollection;
    private MongoCollection<Document> marketItemsCollection;
    private MongoCollection<Document> marketHistoryCollection;

    public MongoDBManager(EconomyPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Conecta ao banco de dados MongoDB
     * @return true se a conexão foi bem-sucedida, false caso contrário
     */
    public boolean connect() {
        try {
            FileConfiguration config = plugin.getConfig();
            String uri = config.getString("mongodb.uri", "mongodb://localhost:27017");
            String dbName = config.getString("mongodb.database", "minecraft_economy");
            
            // Configuração de autenticação, se necessário
            if (config.getBoolean("mongodb.auth.enabled", false)) {
                String username = config.getString("mongodb.auth.username", "");
                String password = config.getString("mongodb.auth.password", "");
                String authSource = config.getString("mongodb.auth.authSource", "admin");
                
                uri = uri.replace("mongodb://", "mongodb://" + username + ":" + password + "@");
                uri += "/?authSource=" + authSource;
            }
            
            // Configurações de conexão
            int timeout = config.getInt("mongodb.connection.timeout", 5000);
            int maxPoolSize = config.getInt("mongodb.connection.maxPoolSize", 10);
            int minPoolSize = config.getInt("mongodb.connection.minPoolSize", 2);
            
            ConnectionString connectionString = new ConnectionString(uri);
            MongoClientSettings settings = MongoClientSettings.builder()
                    .applyConnectionString(connectionString)
                    .applyToConnectionPoolSettings(builder -> 
                        builder.maxSize(maxPoolSize).minSize(minPoolSize))
                    .applyToSocketSettings(builder -> 
                        builder.connectTimeout(timeout, java.util.concurrent.TimeUnit.MILLISECONDS))
                    .build();
            
            mongoClient = MongoClients.create(settings);
            database = mongoClient.getDatabase(dbName);
            
            // Inicializa as coleções
            playersCollection = database.getCollection("players");
            transactionsCollection = database.getCollection("transactions");
            marketItemsCollection = database.getCollection("market_items");
            marketHistoryCollection = database.getCollection("market_history");
            
            // Cria índices para melhorar performance
            createIndices();
            
            plugin.getLogger().info("Conexão com MongoDB estabelecida com sucesso!");
            return true;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Erro ao conectar ao MongoDB: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Cria índices nas coleções para melhorar a performance
     */
    private void createIndices() {
        // Índice para players por UUID
        playersCollection.createIndex(new Document("uuid", 1));
        
        // Índice para transações por data
        transactionsCollection.createIndex(new Document("timestamp", -1));
        
        // Índice para itens do mercado por nome
        marketItemsCollection.createIndex(new Document("item_id", 1));
        
        // Índice para histórico do mercado por item e data
        marketHistoryCollection.createIndex(
            new Document("item_id", 1).append("timestamp", -1)
        );
    }
    
    /**
     * Desconecta do banco de dados MongoDB
     */
    public void disconnect() {
        if (mongoClient != null) {
            mongoClient.close();
            plugin.getLogger().info("Conexão com MongoDB fechada com sucesso!");
        }
    }
    
    /**
     * Verifica se um jogador tem uma conta
     * @param uuid UUID do jogador
     * @return CompletableFuture com o resultado (true se a conta existe)
     */
    public CompletableFuture<Boolean> hasAccount(UUID uuid) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                Document query = new Document("uuid", uuid.toString());
                Document result = playersCollection.find(query).first();
                future.complete(result != null);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao verificar conta: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }
    
    /**
     * Cria uma nova conta para o jogador
     * @param uuid UUID do jogador
     * @param playerName Nome do jogador
     * @param initialBalance Saldo inicial
     * @return CompletableFuture com o resultado (true se a conta foi criada)
     */
    public CompletableFuture<Boolean> createAccount(UUID uuid, String playerName, double initialBalance) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Verifica se a conta já existe
                if (playersCollection.find(new Document("uuid", uuid.toString())).first() != null) {
                    future.complete(false);
                    return;
                }
                
                // Cria o documento do jogador
                Document playerDoc = new Document()
                        .append("uuid", uuid.toString())
                        .append("name", playerName)
                        .append("balance", initialBalance)
                        .append("last_activity", System.currentTimeMillis())
                        .append("created_at", System.currentTimeMillis());
                
                playersCollection.insertOne(playerDoc);
                future.complete(true);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao criar conta: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }
    
    /**
     * Obtém o saldo de um jogador
     * @param uuid UUID do jogador
     * @return CompletableFuture com o saldo do jogador
     */
    public CompletableFuture<Double> getBalance(UUID uuid) {
        CompletableFuture<Double> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                Document query = new Document("uuid", uuid.toString());
                Document result = playersCollection.find(query).first();
                
                if (result != null) {
                    future.complete(result.getDouble("balance"));
                } else {
                    future.complete(0.0);
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao obter saldo: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }
    
    /**
     * Verifica se um jogador tem saldo suficiente
     * @param uuid UUID do jogador
     * @param amount Valor a verificar
     * @return CompletableFuture com o resultado (true se tem saldo suficiente)
     */
    public CompletableFuture<Boolean> has(UUID uuid, double amount) {
        return getBalance(uuid).thenApply(balance -> balance >= amount);
    }
    
    /**
     * Retira dinheiro da conta de um jogador
     * @param uuid UUID do jogador
     * @param amount Valor a retirar
     * @param reason Motivo da transação
     * @return CompletableFuture com o resultado (true se a operação foi bem-sucedida)
     */
    public CompletableFuture<Boolean> withdraw(UUID uuid, double amount, String reason) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Verifica se tem saldo suficiente
                Document query = new Document("uuid", uuid.toString());
                Document result = playersCollection.find(query).first();
                
                if (result == null || result.getDouble("balance") < amount) {
                    future.complete(false);
                    return;
                }
                
                // Atualiza o saldo
                Bson filter = Filters.eq("uuid", uuid.toString());
                Bson update = Updates.combine(
                    Updates.inc("balance", -amount),
                    Updates.set("last_activity", System.currentTimeMillis())
                );
                
                UpdateResult updateResult = playersCollection.updateOne(filter, update);
                
                if (updateResult.getModifiedCount() > 0) {
                    // Registra a transação
                    Document transaction = new Document()
                            .append("uuid", uuid.toString())
                            .append("type", "withdraw")
                            .append("amount", amount)
                            .append("reason", reason)
                            .append("timestamp", System.currentTimeMillis());
                    
                    transactionsCollection.insertOne(transaction);
                    future.complete(true);
                } else {
                    future.complete(false);
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao retirar dinheiro: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }
    
    /**
     * Deposita dinheiro na conta de um jogador
     * @param uuid UUID do jogador
     * @param amount Valor a depositar
     * @param reason Motivo da transação
     * @return CompletableFuture com o resultado (true se a operação foi bem-sucedida)
     */
    public CompletableFuture<Boolean> deposit(UUID uuid, double amount, String reason) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Verifica se a conta existe
                Document query = new Document("uuid", uuid.toString());
                Document result = playersCollection.find(query).first();
                
                if (result == null) {
                    future.complete(false);
                    return;
                }
                
                // Atualiza o saldo
                Bson filter = Filters.eq("uuid", uuid.toString());
                Bson update = Updates.combine(
                    Updates.inc("balance", amount),
                    Updates.set("last_activity", System.currentTimeMillis())
                );
                
                UpdateResult updateResult = playersCollection.updateOne(filter, update);
                
                if (updateResult.getModifiedCount() > 0) {
                    // Registra a transação
                    Document transaction = new Document()
                            .append("uuid", uuid.toString())
                            .append("type", "deposit")
                            .append("amount", amount)
                            .append("reason", reason)
                            .append("timestamp", System.currentTimeMillis());
                    
                    transactionsCollection.insertOne(transaction);
                    future.complete(true);
                } else {
                    future.complete(false);
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao depositar dinheiro: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }
    
    /**
     * Transfere dinheiro entre dois jogadores
     * @param fromUuid UUID do jogador de origem
     * @param toUuid UUID do jogador de destino
     * @param amount Valor a transferir
     * @return CompletableFuture com o resultado (true se a operação foi bem-sucedida)
     */
    public CompletableFuture<Boolean> transferMoney(UUID fromUuid, UUID toUuid, double amount) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        // Aplica taxa de transação, se configurada
        double taxRate = plugin.getConfig().getDouble("taxes.transaction_tax", 0.02);
        double taxAmount = amount * taxRate;
        double finalAmount = amount - taxAmount;
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Verifica se tem saldo suficiente
                Document query = new Document("uuid", fromUuid.toString());
                Document result = playersCollection.find(query).first();
                
                if (result == null || result.getDouble("balance") < amount) {
                    future.complete(false);
                    return;
                }
                
                // Retira do remetente
                boolean withdrawn = withdraw(fromUuid, amount, "Transferência para " + toUuid).join();
                
                if (!withdrawn) {
                    future.complete(false);
                    return;
                }
                
                // Deposita no destinatário (valor após taxa)
                boolean deposited = deposit(toUuid, finalAmount, "Transferência de " + fromUuid).join();
                
                if (!deposited) {
                    // Devolve o dinheiro ao remetente em caso de falha
                    deposit(fromUuid, amount, "Estorno de transferência falha").join();
                    future.complete(false);
                    return;
                }
                
                // Registra a transação
                Document transaction = new Document()
                        .append("from_uuid", fromUuid.toString())
                        .append("to_uuid", toUuid.toString())
                        .append("type", "transfer")
                        .append("amount", amount)
                        .append("tax_amount", taxAmount)
                        .append("final_amount", finalAmount)
                        .append("timestamp", System.currentTimeMillis());
                
                transactionsCollection.insertOne(transaction);
                future.complete(true);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao transferir dinheiro: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }
    
    /**
     * Obtém o ranking dos jogadores mais ricos
     * @param limit Limite de jogadores no ranking
     * @return CompletableFuture com a lista de jogadores mais ricos
     */
    public CompletableFuture<List<Document>> getTopPlayers(int limit) {
        CompletableFuture<List<Document>> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                List<Document> topPlayers = new ArrayList<>();
                playersCollection.find()
                        .sort(new Document("balance", -1))
                        .limit(limit)
                        .into(topPlayers);
                
                future.complete(topPlayers);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao obter ranking: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }
    
    /**
     * Obtém jogadores inativos para aplicar decaimento
     * @param daysThreshold Dias de inatividade para considerar
     * @return CompletableFuture com a lista de jogadores inativos
     */
    public CompletableFuture<List<Document>> getInactivePlayers(int daysThreshold) {
        CompletableFuture<List<Document>> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                long thresholdTime = System.currentTimeMillis() - (daysThreshold * 24 * 60 * 60 * 1000L);
                
                List<Document> inactivePlayers = new ArrayList<>();
                playersCollection.find(
                        Filters.lt("last_activity", thresholdTime)
                ).into(inactivePlayers);
                
                future.complete(inactivePlayers);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao obter jogadores inativos: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }
    
    // Getters para as coleções
    public MongoCollection<Document> getPlayersCollection() {
        return playersCollection;
    }
    
    public MongoCollection<Document> getTransactionsCollection() {
        return transactionsCollection;
    }
    
    public MongoCollection<Document> getMarketItemsCollection() {
        return marketItemsCollection;
    }
    
    public MongoCollection<Document> getMarketHistoryCollection() {
        return marketHistoryCollection;
    }
}
