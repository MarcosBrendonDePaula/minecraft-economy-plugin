package com.minecraft.economy.database;

import com.minecraft.economy.core.EconomyPlugin;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * Gerencia configurações armazenadas no MongoDB
 */
public class ConfigDatabase {

    private final EconomyPlugin plugin;
    private final MongoDBManager mongoDBManager;
    private final Map<String, Object> cachedConfigs;
    private MongoCollection<Document> configCollection;

    public ConfigDatabase(EconomyPlugin plugin) {
        this.plugin = plugin;
        this.mongoDBManager = plugin.getMongoDBManager();
        this.cachedConfigs = new HashMap<>();
        
        // Inicializa a coleção de configurações
        initConfigCollection();
        
        // Carrega as configurações iniciais
        loadConfigs();
    }

    /**
     * Inicializa a coleção de configurações no MongoDB
     */
    private void initConfigCollection() {
        try {
            configCollection = mongoDBManager.getDatabase().getCollection("plugin_configs");
            plugin.getLogger().info("Coleção de configurações inicializada com sucesso!");
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Erro ao inicializar coleção de configurações: " + e.getMessage(), e);
        }
    }

    /**
     * Carrega as configurações do MongoDB para o cache
     */
    public void loadConfigs() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Limpa o cache atual
                cachedConfigs.clear();
                
                // Carrega todas as configurações do banco
                for (Document doc : configCollection.find()) {
                    String key = doc.getString("key");
                    Object value = doc.get("value");
                    cachedConfigs.put(key, value);
                }
                
                plugin.getLogger().info("Configurações carregadas do MongoDB: " + cachedConfigs.size() + " entradas");
                
                // Inicializa configurações padrão se necessário
                initDefaultConfigs();
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao carregar configurações: " + e.getMessage(), e);
            }
        });
    }

    /**
     * Inicializa configurações padrão no banco de dados se não existirem
     */
    private void initDefaultConfigs() {
        // Configurações do algoritmo de preços
        setConfigIfNotExists("shop.algorithm.scarcity_weight", 0.6);
        setConfigIfNotExists("shop.algorithm.demand_weight", 0.4);
        setConfigIfNotExists("shop.price_limits.min_multiplier", 0.1);
        setConfigIfNotExists("shop.price_limits.max_multiplier", 10.0);
        
        // Configurações de impostos
        setConfigIfNotExists("taxes.transaction_tax", 0.02);
        setConfigIfNotExists("taxes.wealth_tax.enabled", true);
        setConfigIfNotExists("taxes.wealth_tax.threshold", 100000.0);
        setConfigIfNotExists("taxes.wealth_tax.rate", 0.01);
        
        // Configurações de decaimento por inatividade
        setConfigIfNotExists("taxes.inactivity_decay.enabled", true);
        setConfigIfNotExists("taxes.inactivity_decay.days_threshold", 7);
        setConfigIfNotExists("taxes.inactivity_decay.daily_rate", 0.005);
    }

    /**
     * Define uma configuração no banco de dados se ela não existir
     * @param key Chave da configuração
     * @param defaultValue Valor padrão
     */
    private void setConfigIfNotExists(String key, Object defaultValue) {
        if (!cachedConfigs.containsKey(key)) {
            setConfig(key, defaultValue);
        }
    }

    /**
     * Obtém uma configuração
     * @param key Chave da configuração
     * @param defaultValue Valor padrão caso a configuração não exista
     * @return Valor da configuração
     */
    public Object getConfig(String key, Object defaultValue) {
        // Primeiro verifica no cache
        if (cachedConfigs.containsKey(key)) {
            return cachedConfigs.get(key);
        }
        
        // Se não estiver no cache, verifica no arquivo de configuração
        if (key.contains(".")) {
            String[] parts = key.split("\\.", 2);
            ConfigurationSection section = plugin.getConfig().getConfigurationSection(parts[0]);
            if (section != null && section.contains(parts[1])) {
                return plugin.getConfig().get(key);
            }
        } else if (plugin.getConfig().contains(key)) {
            return plugin.getConfig().get(key);
        }
        
        // Se não encontrar em nenhum lugar, retorna o valor padrão
        return defaultValue;
    }

    /**
     * Obtém uma configuração como String
     * @param key Chave da configuração
     * @param defaultValue Valor padrão caso a configuração não exista
     * @return Valor da configuração como String
     */
    public String getString(String key, String defaultValue) {
        Object value = getConfig(key, defaultValue);
        return value != null ? value.toString() : defaultValue;
    }

    /**
     * Obtém uma configuração como int
     * @param key Chave da configuração
     * @param defaultValue Valor padrão caso a configuração não exista
     * @return Valor da configuração como int
     */
    public int getInt(String key, int defaultValue) {
        Object value = getConfig(key, defaultValue);
        if (value instanceof Number) {
            return ((Number) value).intValue();
        } else if (value instanceof String) {
            try {
                return Integer.parseInt((String) value);
            } catch (NumberFormatException e) {
                return defaultValue;
            }
        }
        return defaultValue;
    }

    /**
     * Obtém uma configuração como double
     * @param key Chave da configuração
     * @param defaultValue Valor padrão caso a configuração não exista
     * @return Valor da configuração como double
     */
    public double getDouble(String key, double defaultValue) {
        Object value = getConfig(key, defaultValue);
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        } else if (value instanceof String) {
            try {
                return Double.parseDouble((String) value);
            } catch (NumberFormatException e) {
                return defaultValue;
            }
        }
        return defaultValue;
    }

    /**
     * Obtém uma configuração como boolean
     * @param key Chave da configuração
     * @param defaultValue Valor padrão caso a configuração não exista
     * @return Valor da configuração como boolean
     */
    public boolean getBoolean(String key, boolean defaultValue) {
        Object value = getConfig(key, defaultValue);
        if (value instanceof Boolean) {
            return (Boolean) value;
        } else if (value instanceof String) {
            return Boolean.parseBoolean((String) value);
        } else if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }
        return defaultValue;
    }

    /**
     * Define uma configuração
     * @param key Chave da configuração
     * @param value Valor da configuração
     * @return CompletableFuture com o resultado da operação
     */
    public CompletableFuture<Boolean> setConfig(String key, Object value) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        // Atualiza o cache imediatamente
        cachedConfigs.put(key, value);
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Atualiza no banco de dados
                Document filter = new Document("key", key);
                Document update = new Document("$set", new Document("value", value));
                UpdateOptions options = new UpdateOptions().upsert(true);
                
                configCollection.updateOne(filter, update, options);
                future.complete(true);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao definir configuração: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }

    /**
     * Remove uma configuração
     * @param key Chave da configuração
     * @return CompletableFuture com o resultado da operação
     */
    public CompletableFuture<Boolean> removeConfig(String key) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        // Remove do cache imediatamente
        cachedConfigs.remove(key);
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Remove do banco de dados
                Document filter = new Document("key", key);
                configCollection.deleteOne(filter);
                future.complete(true);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao remover configuração: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }
}
