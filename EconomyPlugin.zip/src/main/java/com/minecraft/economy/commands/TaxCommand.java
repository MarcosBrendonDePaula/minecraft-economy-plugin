package com.minecraft.economy.commands;

import com.minecraft.economy.core.EconomyPlugin;
import com.minecraft.economy.database.ConfigDatabase;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.text.DecimalFormat;

/**
 * Comando para gerenciar impostos e configurações econômicas
 */
public class TaxCommand implements CommandExecutor {

    private final EconomyPlugin plugin;
    private final ConfigDatabase configDB;
    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("#,##0.00");

    public TaxCommand(EconomyPlugin plugin) {
        this.plugin = plugin;
        this.configDB = plugin.getConfigDatabase();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("economy.admin")) {
            sender.sendMessage("§cVocê não tem permissão para usar este comando.");
            return true;
        }

        if (args.length == 0) {
            showTaxInfo(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "set":
                if (args.length < 3) {
                    sender.sendMessage("§cUso: /tax set <tipo> <valor>");
                    sender.sendMessage("§cTipos: transaction, wealth, inactivity");
                    return true;
                }
                setTaxRate(sender, args[1], args[2]);
                break;
            case "enable":
                if (args.length < 2) {
                    sender.sendMessage("§cUso: /tax enable <tipo>");
                    sender.sendMessage("§cTipos: wealth, inactivity");
                    return true;
                }
                setTaxEnabled(sender, args[1], true);
                break;
            case "disable":
                if (args.length < 2) {
                    sender.sendMessage("§cUso: /tax disable <tipo>");
                    sender.sendMessage("§cTipos: wealth, inactivity");
                    return true;
                }
                setTaxEnabled(sender, args[1], false);
                break;
            case "apply":
                if (args.length < 2) {
                    sender.sendMessage("§cUso: /tax apply <tipo>");
                    sender.sendMessage("§cTipos: wealth, inactivity");
                    return true;
                }
                applyTax(sender, args[1]);
                break;
            case "info":
                showTaxInfo(sender);
                break;
            default:
                sender.sendMessage("§cComando desconhecido. Use /tax info para ver as opções disponíveis.");
                break;
        }

        return true;
    }

    /**
     * Mostra informações sobre os impostos atuais
     * @param sender Remetente do comando
     */
    private void showTaxInfo(CommandSender sender) {
        sender.sendMessage("§6=== Configurações de Impostos ===");
        
        // Imposto de transação
        double transactionTax = configDB.getDouble("taxes.transaction_tax", 0.02);
        sender.sendMessage("§7Imposto de Transação: §f" + (transactionTax * 100) + "%");
        
        // Imposto sobre riqueza
        boolean wealthTaxEnabled = configDB.getBoolean("taxes.wealth_tax.enabled", true);
        double wealthTaxThreshold = configDB.getDouble("taxes.wealth_tax.threshold", 100000.0);
        double wealthTaxRate = configDB.getDouble("taxes.wealth_tax.rate", 0.01);
        
        sender.sendMessage("§7Imposto sobre Riqueza: §f" + (wealthTaxEnabled ? "§aAtivado" : "§cDesativado"));
        if (wealthTaxEnabled) {
            sender.sendMessage("§7  Limite: §f$" + PRICE_FORMAT.format(wealthTaxThreshold));
            sender.sendMessage("§7  Taxa: §f" + (wealthTaxRate * 100) + "%");
        }
        
        // Decaimento por inatividade
        boolean inactivityEnabled = configDB.getBoolean("taxes.inactivity_decay.enabled", true);
        int inactivityDays = configDB.getInt("taxes.inactivity_decay.days_threshold", 7);
        double inactivityRate = configDB.getDouble("taxes.inactivity_decay.daily_rate", 0.005);
        
        sender.sendMessage("§7Decaimento por Inatividade: §f" + (inactivityEnabled ? "§aAtivado" : "§cDesativado"));
        if (inactivityEnabled) {
            sender.sendMessage("§7  Dias de inatividade: §f" + inactivityDays);
            sender.sendMessage("§7  Taxa diária: §f" + (inactivityRate * 100) + "%");
        }
        
        sender.sendMessage("§6==============================");
    }

    /**
     * Define a taxa de um imposto
     * @param sender Remetente do comando
     * @param type Tipo de imposto
     * @param valueStr Valor da taxa
     */
    private void setTaxRate(CommandSender sender, String type, String valueStr) {
        double value;
        try {
            // Converte de porcentagem para decimal
            value = Double.parseDouble(valueStr.replace("%", "")) / 100.0;
            if (value < 0 || value > 1) {
                sender.sendMessage("§cA taxa deve estar entre 0% e 100%.");
                return;
            }
        } catch (NumberFormatException e) {
            sender.sendMessage("§cValor inválido. Use um número entre 0 e 100.");
            return;
        }
        
        String configKey;
        switch (type.toLowerCase()) {
            case "transaction":
                configKey = "taxes.transaction_tax";
                break;
            case "wealth":
                configKey = "taxes.wealth_tax.rate";
                break;
            case "inactivity":
                configKey = "taxes.inactivity_decay.daily_rate";
                break;
            default:
                sender.sendMessage("§cTipo de imposto desconhecido. Use transaction, wealth ou inactivity.");
                return;
        }
        
        configDB.setConfig(configKey, value).thenAccept(success -> {
            if (success) {
                sender.sendMessage("§aTaxa de " + type + " definida para " + (value * 100) + "%.");
            } else {
                sender.sendMessage("§cErro ao definir a taxa. Tente novamente.");
            }
        });
    }

    /**
     * Ativa ou desativa um tipo de imposto
     * @param sender Remetente do comando
     * @param type Tipo de imposto
     * @param enabled Se deve ativar ou desativar
     */
    private void setTaxEnabled(CommandSender sender, String type, boolean enabled) {
        String configKey;
        switch (type.toLowerCase()) {
            case "wealth":
                configKey = "taxes.wealth_tax.enabled";
                break;
            case "inactivity":
                configKey = "taxes.inactivity_decay.enabled";
                break;
            default:
                sender.sendMessage("§cTipo de imposto desconhecido. Use wealth ou inactivity.");
                return;
        }
        
        configDB.setConfig(configKey, enabled).thenAccept(success -> {
            if (success) {
                sender.sendMessage("§aImposto de " + type + " " + (enabled ? "ativado" : "desativado") + " com sucesso.");
            } else {
                sender.sendMessage("§cErro ao " + (enabled ? "ativar" : "desativar") + " o imposto. Tente novamente.");
            }
        });
    }

    /**
     * Aplica um imposto imediatamente
     * @param sender Remetente do comando
     * @param type Tipo de imposto
     */
    private void applyTax(CommandSender sender, String type) {
        switch (type.toLowerCase()) {
            case "wealth":
                applyWealthTax(sender);
                break;
            case "inactivity":
                applyInactivityDecay(sender);
                break;
            default:
                sender.sendMessage("§cTipo de imposto desconhecido. Use wealth ou inactivity.");
                break;
        }
    }

    /**
     * Aplica o imposto sobre riqueza
     * @param sender Remetente do comando
     */
    private void applyWealthTax(CommandSender sender) {
        if (!configDB.getBoolean("taxes.wealth_tax.enabled", true)) {
            sender.sendMessage("§cO imposto sobre riqueza está desativado.");
            return;
        }
        
        sender.sendMessage("§aAplicando imposto sobre riqueza...");
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                double threshold = configDB.getDouble("taxes.wealth_tax.threshold", 100000.0);
                double rate = configDB.getDouble("taxes.wealth_tax.rate", 0.01);
                
                // Obtém os jogadores mais ricos
                plugin.getMongoDBManager().getTopPlayers(100).thenAccept(players -> {
                    int count = 0;
                    double totalTax = 0;
                    
                    for (org.bson.Document player : players) {
                        double balance = player.getDouble("balance");
                        
                        if (balance > threshold) {
                            String uuidString = player.getString("uuid");
                            java.util.UUID uuid = java.util.UUID.fromString(uuidString);
                            
                            // Calcula o imposto (apenas sobre o valor acima do threshold)
                            double taxableAmount = balance - threshold;
                            double taxAmount = taxableAmount * rate;
                            
                            if (taxAmount > 0) {
                                // Retira o imposto
                                plugin.getMongoDBManager().withdraw(uuid, taxAmount, "Imposto sobre riqueza").join();
                                
                                count++;
                                totalTax += taxAmount;
                                
                                // Notifica o jogador, se estiver online
                                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(uuid);
                                if (offlinePlayer.isOnline()) {
                                    Player onlinePlayer = offlinePlayer.getPlayer();
                                    onlinePlayer.sendMessage("§cVocê pagou §f$" + PRICE_FORMAT.format(taxAmount) + 
                                                           " §cde imposto sobre riqueza.");
                                }
                            }
                        }
                    }
                    
                    // Redistribui parte do imposto para jogadores ativos
                    if (totalTax > 0) {
                        redistributeWealthTax(totalTax);
                    }
                    
                    sender.sendMessage("§aImposto sobre riqueza aplicado a " + count + " jogadores.");
                    sender.sendMessage("§aTotal arrecadado: $" + PRICE_FORMAT.format(totalTax));
                });
            } catch (Exception e) {
                sender.sendMessage("§cErro ao aplicar imposto sobre riqueza: " + e.getMessage());
                plugin.getLogger().severe("Erro ao aplicar imposto sobre riqueza: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    /**
     * Redistribui parte do imposto sobre riqueza para jogadores ativos
     * @param totalTax Total arrecadado
     */
    private void redistributeWealthTax(double totalTax) {
        // Redistribui 50% do imposto entre jogadores ativos
        double redistributeAmount = totalTax * 0.5;
        
        // Obtém jogadores ativos (que jogaram nos últimos 7 dias)
        long activeThreshold = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000L);
        
        plugin.getMongoDBManager().getPlayersCollection()
            .find(new org.bson.Document("last_activity", new org.bson.Document("$gt", activeThreshold)))
            .into(new java.util.ArrayList<>())
            .thenAccept(activePlayers -> {
                if (activePlayers.isEmpty()) return;
                
                // Calcula o valor por jogador
                double amountPerPlayer = redistributeAmount / activePlayers.size();
                
                for (org.bson.Document player : activePlayers) {
                    String uuidString = player.getString("uuid");
                    java.util.UUID uuid = java.util.UUID.fromString(uuidString);
                    
                    // Deposita a parte do jogador
                    plugin.getMongoDBManager().deposit(uuid, amountPerPlayer, "Redistribuição de imposto").join();
                    
                    // Notifica o jogador, se estiver online
                    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(uuid);
                    if (offlinePlayer.isOnline()) {
                        Player onlinePlayer = offlinePlayer.getPlayer();
                        onlinePlayer.sendMessage("§aVocê recebeu §f$" + PRICE_FORMAT.format(amountPerPlayer) + 
                                               " §ade redistribuição de impostos.");
                    }
                }
                
                plugin.getLogger().info("Redistribuído $" + PRICE_FORMAT.format(redistributeAmount) + 
                                      " para " + activePlayers.size() + " jogadores ativos.");
            });
    }

    /**
     * Aplica o decaimento por inatividade
     * @param sender Remetente do comando
     */
    private void applyInactivityDecay(CommandSender sender) {
        if (!configDB.getBoolean("taxes.inactivity_decay.enabled", true)) {
            sender.sendMessage("§cO decaimento por inatividade está desativado.");
            return;
        }
        
        sender.sendMessage("§aAplicando decaimento por inatividade...");
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                int daysThreshold = configDB.getInt("taxes.inactivity_decay.days_threshold", 7);
                double dailyRate = configDB.getDouble("taxes.inactivity_decay.daily_rate", 0.005);
                
                plugin.getEconomyProvider().applyInactivityDecay();
                
                sender.sendMessage("§aDecaimento por inatividade aplicado com sucesso.");
                sender.sendMessage("§aJogadores inativos por mais de " + daysThreshold + " dias tiveram " + 
                                 (dailyRate * 100) + "% de decaimento aplicado.");
            } catch (Exception e) {
                sender.sendMessage("§cErro ao aplicar decaimento por inatividade: " + e.getMessage());
                plugin.getLogger().severe("Erro ao aplicar decaimento por inatividade: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }
}
