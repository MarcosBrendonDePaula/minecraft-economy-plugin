package com.minecraft.economy.commands;

import com.minecraft.economy.core.EconomyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bson.Document;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Comando para gerenciar dinheiro dos jogadores
 */
public class MoneyCommand implements CommandExecutor {

    private final EconomyPlugin plugin;
    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("#,##0.00");

    public MoneyCommand(EconomyPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            // Comando /money - Mostra o saldo do jogador
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cEste comando só pode ser usado por jogadores.");
                return true;
            }

            Player player = (Player) sender;
            showBalance(player, player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "pay":
                // Comando /money pay <jogador> <quantia> - Transfere dinheiro para outro jogador
                if (!(sender instanceof Player)) {
                    sender.sendMessage("§cEste comando só pode ser usado por jogadores.");
                    return true;
                }

                if (args.length < 3) {
                    sender.sendMessage("§cUso: /money pay <jogador> <quantia>");
                    return true;
                }

                Player player = (Player) sender;
                if (!player.hasPermission("economy.money.pay")) {
                    player.sendMessage("§cVocê não tem permissão para transferir dinheiro.");
                    return true;
                }

                transferMoney(player, args[1], args[2]);
                break;

            case "top":
                // Comando /money top - Mostra o ranking de jogadores mais ricos
                if (!sender.hasPermission("economy.money.top")) {
                    sender.sendMessage("§cVocê não tem permissão para ver o ranking.");
                    return true;
                }

                showTopPlayers(sender);
                break;

            default:
                // Comando /money <jogador> - Mostra o saldo de outro jogador
                if (!(sender instanceof Player)) {
                    sender.sendMessage("§cUso: /money <jogador>");
                    return true;
                }

                Player viewer = (Player) sender;
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
                showBalance(viewer, target);
                break;
        }

        return true;
    }

    /**
     * Mostra o saldo de um jogador
     * @param viewer Jogador que está visualizando o saldo
     * @param target Jogador alvo
     */
    private void showBalance(Player viewer, OfflinePlayer target) {
        double balance = plugin.getEconomyProvider().getBalance(target);
        String formattedBalance = plugin.getEconomyProvider().format(balance);

        if (viewer.equals(target)) {
            viewer.sendMessage("§aSeu saldo: §f" + formattedBalance);
        } else {
            viewer.sendMessage("§aSaldo de " + target.getName() + ": §f" + formattedBalance);
        }
    }

    /**
     * Transfere dinheiro para outro jogador
     * @param sender Jogador que está enviando o dinheiro
     * @param targetName Nome do jogador alvo
     * @param amountStr Quantia a ser transferida
     */
    private void transferMoney(Player sender, String targetName, String amountStr) {
        // Verifica se a quantia é válida
        double amount;
        try {
            amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                sender.sendMessage("§cA quantia deve ser maior que zero.");
                return;
            }
        } catch (NumberFormatException e) {
            sender.sendMessage("§cQuantia inválida. Use um número válido.");
            return;
        }

        // Verifica se o jogador alvo existe
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage("§cJogador não encontrado.");
            return;
        }

        // Verifica se o jogador tem saldo suficiente
        if (!plugin.getEconomyProvider().has(sender, amount)) {
            sender.sendMessage("§cVocê não tem dinheiro suficiente.");
            return;
        }

        // Transfere o dinheiro
        UUID fromUuid = sender.getUniqueId();
        UUID toUuid = target.getUniqueId();

        plugin.getMongoDBManager().transferMoney(fromUuid, toUuid, amount).thenAccept(success -> {
            if (success) {
                // Calcula a taxa de transação
                double taxRate = plugin.getConfigDatabase().getDouble("taxes.transaction_tax", 0.02);
                double taxAmount = amount * taxRate;
                double finalAmount = amount - taxAmount;

                sender.sendMessage("§aVocê transferiu §f" + plugin.getEconomyProvider().format(amount) + 
                                  " §apara §f" + target.getName() + "§a.");
                sender.sendMessage("§7Taxa de transação: §f" + plugin.getEconomyProvider().format(taxAmount) + 
                                  " §7(" + (taxRate * 100) + "%)");

                // Notifica o jogador alvo, se estiver online
                if (target.isOnline()) {
                    Player targetPlayer = target.getPlayer();
                    targetPlayer.sendMessage("§aVocê recebeu §f" + plugin.getEconomyProvider().format(finalAmount) + 
                                           " §ade §f" + sender.getName() + "§a.");
                }
            } else {
                sender.sendMessage("§cErro ao transferir dinheiro. Tente novamente.");
            }
        });
    }

    /**
     * Mostra o ranking de jogadores mais ricos
     * @param sender Remetente do comando
     */
    private void showTopPlayers(CommandSender sender) {
        sender.sendMessage("§6=== Jogadores Mais Ricos ===");
        sender.sendMessage("§7Carregando...");

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                List<Document> topPlayers = plugin.getMongoDBManager().getTopPlayers(10).join();
                
                if (topPlayers.isEmpty()) {
                    sender.sendMessage("§cNenhum jogador encontrado.");
                    return;
                }
                
                List<String> messages = new ArrayList<>();
                messages.add("§6=== Jogadores Mais Ricos ===");
                
                int rank = 1;
                for (Document player : topPlayers) {
                    String name = player.getString("name");
                    double balance = player.getDouble("balance");
                    String formattedBalance = plugin.getEconomyProvider().format(balance);
                    
                    messages.add("§7" + rank + ". §f" + name + " §7- §f" + formattedBalance);
                    rank++;
                }
                
                messages.add("§6==========================");
                
                // Envia as mensagens de volta no thread principal
                Bukkit.getScheduler().runTask(plugin, () -> {
                    for (String message : messages) {
                        sender.sendMessage(message);
                    }
                });
            } catch (Exception e) {
                plugin.getLogger().severe("Erro ao obter ranking: " + e.getMessage());
                sender.sendMessage("§cErro ao carregar o ranking. Tente novamente.");
            }
        });
    }
}
