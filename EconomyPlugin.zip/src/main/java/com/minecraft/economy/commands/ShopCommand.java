package com.minecraft.economy.commands;

import com.minecraft.economy.core.EconomyPlugin;
import com.minecraft.economy.database.ConfigDatabase;
import com.minecraft.economy.shop.ShopGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Comando para abrir a interface do shop
 */
public class ShopCommand implements CommandExecutor {

    private final EconomyPlugin plugin;
    private final ShopGUI shopGUI;

    public ShopCommand(EconomyPlugin plugin) {
        this.plugin = plugin;
        this.shopGUI = new ShopGUI(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cEste comando só pode ser usado por jogadores.");
            return true;
        }

        Player player = (Player) sender;

        // Verifica permissão
        if (!player.hasPermission("economy.shop.use")) {
            player.sendMessage("§cVocê não tem permissão para usar o shop.");
            return true;
        }

        // Abre o menu principal do shop
        shopGUI.openMainMenu(player);
        return true;
    }
}
