package com.minecraft.economy.shop;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa uma categoria de itens no shop
 */
public class ShopCategory {
    
    private final String name;
    private final List<ShopItem> items;
    
    public ShopCategory(String name) {
        this.name = name;
        this.items = new ArrayList<>();
    }
    
    /**
     * Adiciona um item à categoria
     * @param item Item a ser adicionado
     */
    public void addItem(ShopItem item) {
        items.add(item);
    }
    
    /**
     * Remove um item da categoria
     * @param item Item a ser removido
     * @return true se o item foi removido, false caso contrário
     */
    public boolean removeItem(ShopItem item) {
        return items.remove(item);
    }
    
    /**
     * Obtém todos os itens da categoria
     * @return Lista de itens
     */
    public List<ShopItem> getItems() {
        return new ArrayList<>(items); // Retorna uma cópia para evitar modificações externas
    }
    
    /**
     * Obtém o nome da categoria
     * @return Nome da categoria
     */
    public String getName() {
        return name;
    }
}
