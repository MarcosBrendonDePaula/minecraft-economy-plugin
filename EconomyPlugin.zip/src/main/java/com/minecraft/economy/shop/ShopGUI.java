package com.minecraft.economy.shop;

import com.minecraft.economy.core.EconomyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Gerencia a interface gráfica do shop
 */
public class ShopGUI {

    private final EconomyPlugin plugin;
    private final ShopManager shopManager;
    private final Map<Player, String> currentCategory;
    private final Map<Player, Integer> currentPage;
    private final Map<Integer, ShopItem> itemSlotMap;
    
    private static final int ITEMS_PER_PAGE = 45; // 5 linhas de 9 slots
    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("#,##0.00");

    public ShopGUI(EconomyPlugin plugin) {
        this.plugin = plugin;
        this.shopManager = plugin.getShopManager();
        this.currentCategory = new HashMap<>();
        this.currentPage = new HashMap<>();
        this.itemSlotMap = new HashMap<>();
    }

    /**
     * Abre o menu principal do shop para um jogador
     * @param player Jogador
     */
    public void openMainMenu(Player player) {
        String title = plugin.getConfig().getString("interface.shop_title", "&8[&6Shop do Servidor&8]")
                .replace("&", "§");
        
        Inventory inventory = Bukkit.createInventory(null, 9, title);
        
        // Adiciona os botões de categoria
        int slot = 0;
        for (ShopCategory category : shopManager.getCategories().values()) {
            ItemStack categoryItem = createCategoryButton(category);
            inventory.setItem(slot++, categoryItem);
        }
        
        player.openInventory(inventory);
    }

    /**
     * Cria um botão para uma categoria
     * @param category Categoria
     * @return ItemStack representando a categoria
     */
    private ItemStack createCategoryButton(ShopCategory category) {
        Material material;
        
        // Escolhe um material baseado na categoria
        switch (category.getName().toLowerCase()) {
            case "blocos":
                material = Material.STONE;
                break;
            case "recursos":
                material = Material.DIAMOND;
                break;
            case "ferramentas":
                material = Material.IRON_PICKAXE;
                break;
            case "armas":
                material = Material.IRON_SWORD;
                break;
            case "comida":
                material = Material.BREAD;
                break;
            default:
                material = Material.CHEST;
                break;
        }
        
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName("§6" + category.getName());
            
            List<String> lore = new ArrayList<>();
            lore.add("§7Clique para ver os itens");
            lore.add("§7desta categoria");
            lore.add("§8" + category.getItems().size() + " itens disponíveis");
            
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        
        return item;
    }

    /**
     * Abre a página de uma categoria para um jogador
     * @param player Jogador
     * @param categoryName Nome da categoria
     * @param page Número da página
     */
    public void openCategoryPage(Player player, String categoryName, int page) {
        ShopCategory category = shopManager.getCategory(categoryName);
        
        if (category == null) {
            player.sendMessage("§cCategoria não encontrada!");
            return;
        }
        
        List<ShopItem> items = category.getItems();
        int totalPages = (int) Math.ceil((double) items.size() / ITEMS_PER_PAGE);
        
        if (page < 0) page = 0;
        if (page >= totalPages) page = totalPages - 1;
        if (page < 0) page = 0; // Se não houver itens
        
        String title = "§6" + category.getName() + " §8- §7Página " + (page + 1) + "/" + Math.max(1, totalPages);
        Inventory inventory = Bukkit.createInventory(null, 54, title); // 6 linhas (5 para itens, 1 para navegação)
        
        // Limpa o mapa de slots
        itemSlotMap.clear();
        
        // Adiciona os itens da página atual
        int startIndex = page * ITEMS_PER_PAGE;
        int endIndex = Math.min(startIndex + ITEMS_PER_PAGE, items.size());
        
        for (int i = startIndex; i < endIndex; i++) {
            ShopItem shopItem = items.get(i);
            int slot = i - startIndex;
            
            ItemStack displayItem = createShopItemDisplay(shopItem);
            inventory.setItem(slot, displayItem);
            
            // Mapeia o slot ao item para referência futura
            itemSlotMap.put(slot, shopItem);
        }
        
        // Adiciona botões de navegação na última linha
        if (page > 0) {
            // Botão de página anterior
            ItemStack prevButton = new ItemStack(Material.ARROW);
            ItemMeta meta = prevButton.getItemMeta();
            if (meta != null) {
                meta.setDisplayName("§aPágina Anterior");
                prevButton.setItemMeta(meta);
            }
            inventory.setItem(45, prevButton);
        }
        
        // Botão de voltar ao menu principal
        ItemStack backButton = new ItemStack(Material.BARRIER);
        ItemMeta backMeta = backButton.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§cVoltar ao Menu Principal");
            backButton.setItemMeta(backMeta);
        }
        inventory.setItem(49, backButton);
        
        if (page < totalPages - 1) {
            // Botão de próxima página
            ItemStack nextButton = new ItemStack(Material.ARROW);
            ItemMeta meta = nextButton.getItemMeta();
            if (meta != null) {
                meta.setDisplayName("§aPróxima Página");
                nextButton.setItemMeta(meta);
            }
            inventory.setItem(53, nextButton);
        }
        
        // Atualiza o estado do jogador
        currentCategory.put(player, categoryName);
        currentPage.put(player, page);
        
        player.openInventory(inventory);
    }

    /**
     * Cria um item de exibição para o shop
     * @param shopItem Item do shop
     * @return ItemStack para exibição
     */
    private ItemStack createShopItemDisplay(ShopItem shopItem) {
        ItemStack displayItem = shopItem.getItemStack().clone();
        ItemMeta meta = displayItem.getItemMeta();
        
        if (meta != null) {
            List<String> lore = new ArrayList<>();
            
            // Adiciona informações de preço e estoque
            lore.add("§7Preço: §a$" + PRICE_FORMAT.format(shopItem.getCurrentPrice()));
            lore.add("§7Estoque: §f" + shopItem.getStock() + " unidades");
            
            // Adiciona tendência de preço
            double priceRatio = shopItem.getCurrentPrice() / shopItem.getBasePrice();
            String trend;
            
            if (priceRatio > 1.5) {
                trend = "§c↑↑ Muito alto";
            } else if (priceRatio > 1.1) {
                trend = "§e↑ Acima do normal";
            } else if (priceRatio < 0.5) {
                trend = "§a↓↓ Muito baixo";
            } else if (priceRatio < 0.9) {
                trend = "§2↓ Abaixo do normal";
            } else {
                trend = "§7→ Estável";
            }
            
            lore.add("§7Tendência: " + trend);
            lore.add("");
            lore.add("§eClique esquerdo para comprar");
            lore.add("§eClique direito para vender");
            
            meta.setLore(lore);
            displayItem.setItemMeta(meta);
        }
        
        return displayItem;
    }

    /**
     * Abre o menu de compra para um item
     * @param player Jogador
     * @param shopItem Item do shop
     */
    public void openBuyMenu(Player player, ShopItem shopItem) {
        String title = "§aComprar §f" + shopItem.getDisplayName();
        Inventory inventory = Bukkit.createInventory(null, 27, title);
        
        // Informações do item
        ItemStack infoItem = shopItem.getItemStack().clone();
        ItemMeta infoMeta = infoItem.getItemMeta();
        
        if (infoMeta != null) {
            List<String> lore = new ArrayList<>();
            lore.add("§7Preço: §a$" + PRICE_FORMAT.format(shopItem.getCurrentPrice()) + " por unidade");
            lore.add("§7Estoque: §f" + shopItem.getStock() + " unidades");
            
            double playerBalance = plugin.getEconomyProvider().getBalance(player);
            int maxAffordable = (int) (playerBalance / shopItem.getCurrentPrice());
            maxAffordable = Math.min(maxAffordable, shopItem.getStock());
            
            lore.add("§7Seu saldo: §a$" + PRICE_FORMAT.format(playerBalance));
            lore.add("§7Você pode comprar até §f" + maxAffordable + " unidades");
            
            infoMeta.setLore(lore);
            infoItem.setItemMeta(infoMeta);
        }
        
        inventory.setItem(4, infoItem);
        
        // Botões de quantidade
        addQuantityButton(inventory, shopItem, 1, 10);
        addQuantityButton(inventory, shopItem, 5, 12);
        addQuantityButton(inventory, shopItem, 10, 14);
        addQuantityButton(inventory, shopItem, 32, 16);
        
        // Botão de voltar
        ItemStack backButton = new ItemStack(Material.BARRIER);
        ItemMeta backMeta = backButton.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§cVoltar");
            backButton.setItemMeta(backMeta);
        }
        inventory.setItem(22, backButton);
        
        player.openInventory(inventory);
    }

    /**
     * Adiciona um botão de quantidade ao menu de compra
     * @param inventory Inventário
     * @param shopItem Item do shop
     * @param quantity Quantidade
     * @param slot Slot
     */
    private void addQuantityButton(Inventory inventory, ShopItem shopItem, int quantity, int slot) {
        ItemStack button = new ItemStack(Material.EMERALD, Math.min(quantity, 64));
        ItemMeta meta = button.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName("§aComprar " + quantity + " unidades");
            
            List<String> lore = new ArrayList<>();
            double totalPrice = shopItem.getCurrentPrice() * quantity;
            lore.add("§7Preço total: §a$" + PRICE_FORMAT.format(totalPrice));
            
            meta.setLore(lore);
            button.setItemMeta(meta);
        }
        
        inventory.setItem(slot, button);
    }

    /**
     * Abre o menu de venda para um item
     * @param player Jogador
     * @param shopItem Item do shop
     */
    public void openSellMenu(Player player, ShopItem shopItem) {
        String title = "§cVender §f" + shopItem.getDisplayName();
        Inventory inventory = Bukkit.createInventory(null, 27, title);
        
        // Informações do item
        ItemStack infoItem = shopItem.getItemStack().clone();
        ItemMeta infoMeta = infoItem.getItemMeta();
        
        if (infoMeta != null) {
            List<String> lore = new ArrayList<>();
            double sellPrice = shopItem.getCurrentPrice() * 0.7; // 70% do preço de compra
            lore.add("§7Preço de venda: §a$" + PRICE_FORMAT.format(sellPrice) + " por unidade");
            
            // Conta quantos itens o jogador tem no inventário
            int playerHas = countPlayerItems(player, shopItem);
            lore.add("§7Você possui: §f" + playerHas + " unidades");
            
            infoMeta.setLore(lore);
            infoItem.setItemMeta(infoMeta);
        }
        
        inventory.setItem(4, infoItem);
        
        // Botões de quantidade
        addSellQuantityButton(inventory, shopItem, 1, 10);
        addSellQuantityButton(inventory, shopItem, 5, 12);
        addSellQuantityButton(inventory, shopItem, 10, 14);
        addSellQuantityButton(inventory, shopItem, 32, 16);
        
        // Botão de vender tudo
        ItemStack sellAllButton = new ItemStack(Material.GOLD_INGOT);
        ItemMeta sellAllMeta = sellAllButton.getItemMeta();
        if (sellAllMeta != null) {
            sellAllMeta.setDisplayName("§aVender Tudo");
            
            List<String> lore = new ArrayList<>();
            int playerHas = countPlayerItems(player, shopItem);
            double totalPrice = shopItem.getCurrentPrice() * 0.7 * playerHas;
            lore.add("§7Vender todas as §f" + playerHas + " unidades");
            lore.add("§7Valor total: §a$" + PRICE_FORMAT.format(totalPrice));
            
            sellAllMeta.setLore(lore);
            sellAllButton.setItemMeta(sellAllMeta);
        }
        inventory.setItem(18, sellAllButton);
        
        // Botão de voltar
        ItemStack backButton = new ItemStack(Material.BARRIER);
        ItemMeta backMeta = backButton.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§cVoltar");
            backButton.setItemMeta(backMeta);
        }
        inventory.setItem(22, backButton);
        
        player.openInventory(inventory);
    }

    /**
     * Adiciona um botão de quantidade ao menu de venda
     * @param inventory Inventário
     * @param shopItem Item do shop
     * @param quantity Quantidade
     * @param slot Slot
     */
    private void addSellQuantityButton(Inventory inventory, ShopItem shopItem, int quantity, int slot) {
        ItemStack button = new ItemStack(Material.GOLD_NUGGET, Math.min(quantity, 64));
        ItemMeta meta = button.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName("§aVender " + quantity + " unidades");
            
            List<String> lore = new ArrayList<>();
            double sellPrice = shopItem.getCurrentPrice() * 0.7; // 70% do preço de compra
            double totalPrice = sellPrice * quantity;
            lore.add("§7Valor total: §a$" + PRICE_FORMAT.format(totalPrice));
            
            meta.setLore(lore);
            button.setItemMeta(meta);
        }
        
        inventory.setItem(slot, button);
    }

    /**
     * Conta quantos itens do tipo especificado o jogador tem no inventário
     * @param player Jogador
     * @param shopItem Item do shop
     * @return Quantidade de itens
     */
    private int countPlayerItems(Player player, ShopItem shopItem) {
        int count = 0;
        ItemStack targetItem = shopItem.getItemStack();
        
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == targetItem.getType()) {
                // Para itens de mods, precisamos verificar mais detalhes
                if (shopItem.getItemId().contains(":")) {
                    // Verificação adicional para itens de mods
                    if (item.getItemMeta() != null && targetItem.getItemMeta() != null) {
                        // Comparação mais detalhada pode ser necessária dependendo do mod
                        if (item.getItemMeta().equals(targetItem.getItemMeta())) {
                            count += item.getAmount();
                        }
                    }
                } else {
                    // Para itens vanilla, apenas o tipo é suficiente
                    count += item.getAmount();
                }
            }
        }
        
        return count;
    }

    /**
     * Processa um clique no inventário do shop
     * @param event Evento de clique
     */
    public void handleInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        Player player = (Player) event.getWhoClicked();
        String title = event.getView().getTitle();
        int slot = event.getRawSlot();
        
        // Menu principal (categorias)
        if (title.contains("Shop do Servidor")) {
            event.setCancelled(true);
            
            if (slot >= 0 && slot < shopManager.getCategories().size()) {
                String categoryName = (String) shopManager.getCategories().keySet().toArray()[slot];
                openCategoryPage(player, categoryName, 0);
            }
            
            return;
        }
        
        // Página de categoria
        for (String categoryName : shopManager.getCategories().keySet()) {
            if (title.contains(categoryName)) {
                event.setCancelled(true);
                
                // Botões de navegação
                if (slot == 45 && currentPage.getOrDefault(player, 0) > 0) {
                    // Página anterior
                    openCategoryPage(player, categoryName, currentPage.get(player) - 1);
                    return;
                }
                
                if (slot == 53) {
                    // Próxima página
                    openCategoryPage(player, categoryName, currentPage.get(player) + 1);
                    return;
                }
                
                if (slot == 49) {
                    // Voltar ao menu principal
                    openMainMenu(player);
                    return;
                }
                
                // Clique em um item
                if (slot < 45 && itemSlotMap.containsKey(slot)) {
                    ShopItem shopItem = itemSlotMap.get(slot);
                    
                    if (event.isLeftClick()) {
                        // Comprar
                        openBuyMenu(player, shopItem);
                    } else if (event.isRightClick()) {
                        // Vender
                        openSellMenu(player, shopItem);
                    }
                }
                
                return;
            }
        }
        
        // Menu de compra
        if (title.startsWith("§aComprar")) {
            event.setCancelled(true);
            
            if (slot == 22) {
                // Voltar
                String category = currentCategory.getOrDefault(player, "Blocos");
                int page = currentPage.getOrDefault(player, 0);
                openCategoryPage(player, category, page);
                return;
            }
            
            // Botões de quantidade
            int quantity = 0;
            
            if (slot == 10) quantity = 1;
            else if (slot == 12) quantity = 5;
            else if (slot == 14) quantity = 10;
            else if (slot == 16) quantity = 32;
            
            if (quantity > 0) {
                // Extrai o nome do item do título
                String itemName = title.substring(10); // Remove "§aComprar §f"
                
                // Encontra o item correspondente
                ShopItem shopItem = null;
                for (ShopItem item : shopManager.getShopItems().values()) {
                    if (item.getDisplayName().equals(itemName)) {
                        shopItem = item;
                        break;
                    }
                }
                
                if (shopItem != null) {
                    buyItem(player, shopItem, quantity);
                }
            }
            
            return;
        }
        
        // Menu de venda
        if (title.startsWith("§cVender")) {
            event.setCancelled(true);
            
            if (slot == 22) {
                // Voltar
                String category = currentCategory.getOrDefault(player, "Blocos");
                int page = currentPage.getOrDefault(player, 0);
                openCategoryPage(player, category, page);
                return;
            }
            
            // Extrai o nome do item do título
            String itemName = title.substring(9); // Remove "§cVender §f"
            
            // Encontra o item correspondente
            ShopItem shopItem = null;
            for (ShopItem item : shopManager.getShopItems().values()) {
                if (item.getDisplayName().equals(itemName)) {
                    shopItem = item;
                    break;
                }
            }
            
            if (shopItem != null) {
                // Botões de quantidade
                int quantity = 0;
                
                if (slot == 10) quantity = 1;
                else if (slot == 12) quantity = 5;
                else if (slot == 14) quantity = 10;
                else if (slot == 16) quantity = 32;
                else if (slot == 18) quantity = countPlayerItems(player, shopItem); // Vender tudo
                
                if (quantity > 0) {
                    sellItem(player, shopItem, quantity);
                }
            }
            
            return;
        }
    }

    /**
     * Processa a compra de um item
     * @param player Jogador
     * @param shopItem Item do shop
     * @param quantity Quantidade
     */
    private void buyItem(Player player, ShopItem shopItem, int quantity) {
        // Verifica se há estoque suficiente
        if (shopItem.getStock() < quantity) {
            player.sendMessage("§cEstoque insuficiente! Apenas " + shopItem.getStock() + " unidades disponíveis.");
            return;
        }
        
        // Calcula o preço total
        double totalPrice = shopItem.getCurrentPrice() * quantity;
        
        // Verifica se o jogador tem dinheiro suficiente
        if (!plugin.getEconomyProvider().has(player, totalPrice)) {
            player.sendMessage("§cVocê não tem dinheiro suficiente! Necessário: $" + PRICE_FORMAT.format(totalPrice));
            return;
        }
        
        // Processa a compra
        shopManager.buyItem(player.getUniqueId().toString(), shopItem.getItemId(), quantity).thenAccept(success -> {
            if (success) {
                // Adiciona o item ao inventário do jogador
                ItemStack itemStack = shopItem.createItemStack(quantity);
                HashMap<Integer, ItemStack> notAdded = player.getInventory().addItem(itemStack);
                
                // Se não couber tudo no inventário, dropa o resto no chão
                if (!notAdded.isEmpty()) {
                    for (ItemStack item : notAdded.values()) {
                        player.getWorld().dropItem(player.getLocation(), item);
                    }
                    player.sendMessage("§aCompra realizada, mas seu inventário está cheio! Alguns itens foram dropados no chão.");
                } else {
                    player.sendMessage("§aVocê comprou " + quantity + "x " + shopItem.getDisplayName() + 
                                      " por $" + PRICE_FORMAT.format(totalPrice));
                }
                
                // Fecha o inventário e atualiza a visualização
                Bukkit.getScheduler().runTask(plugin, () -> {
                    player.closeInventory();
                    String category = currentCategory.getOrDefault(player, "Blocos");
                    int page = currentPage.getOrDefault(player, 0);
                    openCategoryPage(player, category, page);
                });
            } else {
                player.sendMessage("§cErro ao processar a compra. Tente novamente.");
            }
        });
    }

    /**
     * Processa a venda de um item
     * @param player Jogador
     * @param shopItem Item do shop
     * @param quantity Quantidade
     */
    private void sellItem(Player player, ShopItem shopItem, int quantity) {
        // Verifica se o jogador tem itens suficientes
        int playerHas = countPlayerItems(player, shopItem);
        
        if (playerHas < quantity) {
            player.sendMessage("§cVocê não tem itens suficientes! Apenas " + playerHas + " unidades disponíveis.");
            return;
        }
        
        // Calcula o preço de venda
        double sellPrice = shopItem.getCurrentPrice() * 0.7; // 70% do preço de compra
        double totalPrice = sellPrice * quantity;
        
        // Remove os itens do inventário do jogador
        removeItemsFromInventory(player, shopItem, quantity);
        
        // Processa a venda
        shopManager.sellItem(player.getUniqueId().toString(), shopItem.getItemId(), quantity).thenAccept(success -> {
            if (success) {
                player.sendMessage("§aVocê vendeu " + quantity + "x " + shopItem.getDisplayName() + 
                                  " por $" + PRICE_FORMAT.format(totalPrice));
                
                // Fecha o inventário e atualiza a visualização
                Bukkit.getScheduler().runTask(plugin, () -> {
                    player.closeInventory();
                    String category = currentCategory.getOrDefault(player, "Blocos");
                    int page = currentPage.getOrDefault(player, 0);
                    openCategoryPage(player, category, page);
                });
            } else {
                // Devolve os itens em caso de erro
                ItemStack itemStack = shopItem.createItemStack(quantity);
                player.getInventory().addItem(itemStack);
                player.sendMessage("§cErro ao processar a venda. Os itens foram devolvidos.");
            }
        });
    }

    /**
     * Remove uma quantidade específica de itens do inventário do jogador
     * @param player Jogador
     * @param shopItem Item do shop
     * @param quantity Quantidade a remover
     */
    private void removeItemsFromInventory(Player player, ShopItem shopItem, int quantity) {
        int remaining = quantity;
        ItemStack targetItem = shopItem.getItemStack();
        
        for (int i = 0; i < player.getInventory().getSize() && remaining > 0; i++) {
            ItemStack item = player.getInventory().getItem(i);
            
            if (item != null && item.getType() == targetItem.getType()) {
                // Para itens de mods, precisamos verificar mais detalhes
                boolean isMatch = true;
                
                if (shopItem.getItemId().contains(":")) {
                    // Verificação adicional para itens de mods
                    if (item.getItemMeta() != null && targetItem.getItemMeta() != null) {
                        // Comparação mais detalhada pode ser necessária dependendo do mod
                        isMatch = item.getItemMeta().equals(targetItem.getItemMeta());
                    }
                }
                
                if (isMatch) {
                    if (item.getAmount() <= remaining) {
                        remaining -= item.getAmount();
                        player.getInventory().setItem(i, null);
                    } else {
                        item.setAmount(item.getAmount() - remaining);
                        remaining = 0;
                    }
                }
            }
        }
    }
}
