package com.minecraft.economy.shop;

import com.minecraft.economy.core.EconomyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bson.Document;
import org.bukkit.Registry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

public class ShopManager {

    private final EconomyPlugin plugin;
    private final Map<String, ShopItem> shopItems;
    private final Map<String, ShopCategory> categories;
    private final NamespacedKey itemIdKey;

    public ShopManager(EconomyPlugin plugin) {
        this.plugin = plugin;
        this.shopItems = new HashMap<>();
        this.categories = new HashMap<>();
        this.itemIdKey = new NamespacedKey(plugin, "shop_item_id");
        
        // Carrega as categorias e itens
        loadCategories();
        loadItems();
        
        // Agenda a atualização periódica de preços
        scheduleUpdates();
    }

    /**
     * Carrega as categorias do shop da configuração
     */
    private void loadCategories() {
        List<String> categoryNames = plugin.getConfig().getStringList("interface.categories");
        
        for (String name : categoryNames) {
            ShopCategory category = new ShopCategory(name);
            categories.put(name.toLowerCase(), category);
        }
        
        plugin.getLogger().info("Carregadas " + categories.size() + " categorias para o shop");
    }

    /**
     * Carrega os itens do shop do banco de dados
     */
    private void loadItems() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Carrega itens do banco de dados
                List<Document> items = new ArrayList<>();
                plugin.getMongoDBManager().getMarketItemsCollection().find().into(items);
                
                if (items.isEmpty()) {
                    // Se não houver itens no banco, carrega os padrões
                    loadDefaultItems();
                    return;
                }
                
                for (Document doc : items) {
                    String itemId = doc.getString("item_id");
                    String displayName = doc.getString("display_name");
                    String category = doc.getString("category");
                    double basePrice = doc.getDouble("base_price");
                    double currentPrice = doc.getDouble("current_price");
                    int stock = doc.getInteger("stock", 0);
                    
                    // Cria o ItemStack
                    ItemStack itemStack;
                    
                    // Verifica se é um item de mod ou vanilla
                    if (itemId.contains(":")) {
                        // Item de mod (formato namespace:key)
                        String[] parts = itemId.split(":");
                        String namespace = parts[0];
                        String key = parts[1];
                        
                        // Tenta obter o material do registro
                        NamespacedKey namespacedKey = new NamespacedKey(namespace, key);
                        Material material = Registry.MATERIAL.get(namespacedKey);
                        
                        if (material != null) {
                            itemStack = new ItemStack(material);
                        } else {
                            // Fallback para caso o item não seja encontrado
                            plugin.getLogger().warning("Item de mod não encontrado: " + itemId);
                            itemStack = new ItemStack(Material.BARRIER);
                        }
                    } else {
                        // Item vanilla
                        try {
                            Material material = Material.valueOf(itemId.toUpperCase());
                            itemStack = new ItemStack(material);
                        } catch (IllegalArgumentException e) {
                            plugin.getLogger().warning("Material inválido: " + itemId);
                            itemStack = new ItemStack(Material.BARRIER);
                        }
                    }
                    
                    // Configura o meta do item
                    ItemMeta meta = itemStack.getItemMeta();
                    if (meta != null) {
                        meta.setDisplayName(displayName.replace("&", "§"));
                        meta.getPersistentDataContainer().set(itemIdKey, PersistentDataType.STRING, itemId);
                        itemStack.setItemMeta(meta);
                    }
                    
                    // Cria o item do shop
                    ShopItem shopItem = new ShopItem(itemId, displayName, itemStack, category, basePrice, currentPrice, stock);
                    shopItems.put(itemId, shopItem);
                    
                    // Adiciona à categoria
                    if (categories.containsKey(category.toLowerCase())) {
                        categories.get(category.toLowerCase()).addItem(shopItem);
                    }
                }
                
                plugin.getLogger().info("Carregados " + shopItems.size() + " itens para o shop");
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao carregar itens do shop: " + e.getMessage(), e);
            }
        });
    }

    /**
     * Carrega itens padrão para o shop (usado quando o banco de dados está vazio)
     */
    private void loadDefaultItems() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                List<Document> defaultItems = new ArrayList<>();
                
                // Adiciona alguns itens padrão para cada categoria
                addDefaultItemsForCategory("Blocos", defaultItems);
                addDefaultItemsForCategory("Recursos", defaultItems);
                addDefaultItemsForCategory("Ferramentas", defaultItems);
                addDefaultItemsForCategory("Armas", defaultItems);
                addDefaultItemsForCategory("Comida", defaultItems);
                addDefaultItemsForCategory("Diversos", defaultItems);
                
                // Insere os itens no banco de dados
                if (!defaultItems.isEmpty()) {
                    plugin.getMongoDBManager().getMarketItemsCollection().insertMany(defaultItems);
                    plugin.getLogger().info("Adicionados " + defaultItems.size() + " itens padrão ao shop");
                }
                
                // Recarrega os itens
                loadItems();
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao carregar itens padrão: " + e.getMessage(), e);
            }
        });
    }

    /**
     * Adiciona itens padrão para uma categoria específica
     * @param category Nome da categoria
     * @param defaultItems Lista para adicionar os itens
     */
    private void addDefaultItemsForCategory(String category, List<Document> defaultItems) {
        switch (category) {
            case "Blocos":
                addDefaultItem("STONE", "Pedra", category, 10.0, 100, defaultItems);
                addDefaultItem("DIRT", "Terra", category, 5.0, 100, defaultItems);
                addDefaultItem("COBBLESTONE", "Pedregulho", category, 8.0, 100, defaultItems);
                addDefaultItem("OAK_PLANKS", "Tábuas de Carvalho", category, 15.0, 100, defaultItems);
                addDefaultItem("GLASS", "Vidro", category, 20.0, 50, defaultItems);
                break;
            case "Recursos":
                addDefaultItem("IRON_INGOT", "Barra de Ferro", category, 100.0, 50, defaultItems);
                addDefaultItem("GOLD_INGOT", "Barra de Ouro", category, 200.0, 30, defaultItems);
                addDefaultItem("DIAMOND", "Diamante", category, 500.0, 10, defaultItems);
                addDefaultItem("EMERALD", "Esmeralda", category, 400.0, 15, defaultItems);
                addDefaultItem("COAL", "Carvão", category, 50.0, 80, defaultItems);
                break;
            case "Ferramentas":
                addDefaultItem("IRON_PICKAXE", "Picareta de Ferro", category, 250.0, 20, defaultItems);
                addDefaultItem("DIAMOND_PICKAXE", "Picareta de Diamante", category, 1000.0, 5, defaultItems);
                addDefaultItem("IRON_SHOVEL", "Pá de Ferro", category, 200.0, 20, defaultItems);
                addDefaultItem("IRON_AXE", "Machado de Ferro", category, 250.0, 20, defaultItems);
                addDefaultItem("SHEARS", "Tesoura", category, 150.0, 30, defaultItems);
                break;
            case "Armas":
                addDefaultItem("IRON_SWORD", "Espada de Ferro", category, 300.0, 20, defaultItems);
                addDefaultItem("DIAMOND_SWORD", "Espada de Diamante", category, 1200.0, 5, defaultItems);
                addDefaultItem("BOW", "Arco", category, 400.0, 15, defaultItems);
                addDefaultItem("ARROW", "Flecha", category, 5.0, 100, defaultItems);
                addDefaultItem("SHIELD", "Escudo", category, 350.0, 15, defaultItems);
                break;
            case "Comida":
                addDefaultItem("BREAD", "Pão", category, 30.0, 50, defaultItems);
                addDefaultItem("COOKED_BEEF", "Bife Assado", category, 60.0, 40, defaultItems);
                addDefaultItem("GOLDEN_APPLE", "Maçã Dourada", category, 500.0, 5, defaultItems);
                addDefaultItem("CAKE", "Bolo", category, 150.0, 20, defaultItems);
                addDefaultItem("COOKIE", "Biscoito", category, 15.0, 100, defaultItems);
                break;
            case "Diversos":
                addDefaultItem("ENDER_PEARL", "Pérola do Fim", category, 200.0, 20, defaultItems);
                addDefaultItem("EXPERIENCE_BOTTLE", "Frasco de Experiência", category, 300.0, 15, defaultItems);
                addDefaultItem("NAME_TAG", "Etiqueta", category, 400.0, 10, defaultItems);
                addDefaultItem("SADDLE", "Sela", category, 500.0, 5, defaultItems);
                addDefaultItem("TOTEM_OF_UNDYING", "Totem da Imortalidade", category, 2000.0, 2, defaultItems);
                break;
        }
    }

    /**
     * Adiciona um item padrão à lista
     */
    private void addDefaultItem(String itemId, String displayName, String category, double basePrice, int stock, List<Document> items) {
        Document item = new Document()
                .append("item_id", itemId)
                .append("display_name", "&f" + displayName)
                .append("category", category)
                .append("base_price", basePrice)
                .append("current_price", basePrice)
                .append("stock", stock)
                .append("last_update", System.currentTimeMillis());
        
        items.add(item);
    }

    /**
     * Agenda a atualização periódica de preços
     */
    private void scheduleUpdates() {
        int updateInterval = plugin.getConfig().getInt("shop.update_interval", 30) * 1200; // Converte minutos para ticks
        
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::updateAllPrices, updateInterval, updateInterval);
    }

    /**
     * Atualiza os preços de todos os itens com base na oferta e demanda
     */
    public void updateAllPrices() {
        for (ShopItem item : shopItems.values()) {
            updateItemPrice(item);
        }
    }

    /**
     * Atualiza o preço de um item específico com base na oferta e demanda
     * @param item Item a ser atualizado
     */
    private void updateItemPrice(ShopItem item) {
        try {
            // Obtém os parâmetros do algoritmo de preços
            double scarcityWeight = plugin.getConfig().getDouble("shop.algorithm.scarcity_weight", 0.6);
            double demandWeight = plugin.getConfig().getDouble("shop.algorithm.demand_weight", 0.4);
            double minMultiplier = plugin.getConfig().getDouble("shop.price_limits.min_multiplier", 0.1);
            double maxMultiplier = plugin.getConfig().getDouble("shop.price_limits.max_multiplier", 10.0);
            
            // Calcula o fator de escassez (quanto menor o estoque, maior o preço)
            double scarcityFactor = calculateScarcityFactor(item.getStock());
            
            // Calcula o fator de demanda (quanto mais transações recentes, maior o preço)
            double demandFactor = calculateDemandFactor(item.getItemId());
            
            // Calcula o novo preço
            double basePrice = item.getBasePrice();
            double priceMultiplier = 1.0 + (scarcityFactor * scarcityWeight) + (demandFactor * demandWeight);
            
            // Aplica limites
            if (priceMultiplier < minMultiplier) priceMultiplier = minMultiplier;
            if (priceMultiplier > maxMultiplier) priceMultiplier = maxMultiplier;
            
            double newPrice = basePrice * priceMultiplier;
            
            // Atualiza o preço no objeto e no banco de dados
            item.setCurrentPrice(newPrice);
            
            // Atualiza no banco de dados
            Document filter = new Document("item_id", item.getItemId());
            Document update = new Document("$set", new Document()
                    .append("current_price", newPrice)
                    .append("last_update", System.currentTimeMillis()));
            
            plugin.getMongoDBManager().getMarketItemsCollection().updateOne(filter, update);
            
            // Registra o histórico de preços
            Document history = new Document()
                    .append("item_id", item.getItemId())
                    .append("price", newPrice)
                    .append("stock", item.getStock())
                    .append("timestamp", System.currentTimeMillis());
            
            plugin.getMongoDBManager().getMarketHistoryCollection().insertOne(history);
            
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Erro ao atualizar preço do item " + item.getItemId() + ": " + e.getMessage(), e);
        }
    }

    /**
     * Calcula o fator de escassez com base no estoque
     * @param stock Quantidade em estoque
     * @return Fator de escassez (0.0 a 1.0)
     */
    private double calculateScarcityFactor(int stock) {
        // Quanto menor o estoque, maior o fator (mais caro)
        if (stock <= 0) return 1.0; // Estoque zero = preço máximo
        if (stock >= 100) return 0.0; // Estoque grande = preço mínimo
        
        return 1.0 - (stock / 100.0);
    }

    /**
     * Calcula o fator de demanda com base nas transações recentes
     * @param itemId ID do item
     * @return Fator de demanda (0.0 a 1.0)
     */
    private double calculateDemandFactor(String itemId) {
        try {
            // Obtém o período de análise (em dias)
            int historyDays = plugin.getConfig().getInt("shop.algorithm.history_days", 7);
            long historyTime = System.currentTimeMillis() - (historyDays * 24 * 60 * 60 * 1000L);
            
            // Conta as transações recentes para este item
            Document query = new Document()
                    .append("item_id", itemId)
                    .append("timestamp", new Document("$gt", historyTime));
            
            long transactionCount = plugin.getMongoDBManager().getTransactionsCollection().countDocuments(query);
            
            // Normaliza para um fator entre 0.0 e 1.0
            // Assumindo que 50 transações no período é o máximo esperado
            double factor = Math.min(transactionCount / 50.0, 1.0);
            
            return factor;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Erro ao calcular fator de demanda: " + e.getMessage(), e);
            return 0.0;
        }
    }

    /**
     * Compra um item do shop
     * @param playerUUID UUID do jogador
     * @param itemId ID do item
     * @param quantity Quantidade a comprar
     * @return CompletableFuture com o resultado da compra
     */
    public CompletableFuture<Boolean> buyItem(String playerUUID, String itemId, int quantity) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Verifica se o item existe
                if (!shopItems.containsKey(itemId)) {
                    future.complete(false);
                    return;
                }
                
                ShopItem item = shopItems.get(itemId);
                
                // Verifica se há estoque suficiente
                if (item.getStock() < quantity) {
                    future.complete(false);
                    return;
                }
                
                // Calcula o preço total
                double totalPrice = item.getCurrentPrice() * quantity;
                
                // Verifica se o jogador tem dinheiro suficiente
                if (!plugin.getEconomyProvider().has(Bukkit.getOfflinePlayer(java.util.UUID.fromString(playerUUID)), totalPrice)) {
                    future.complete(false);
                    return;
                }
                
                // Retira o dinheiro do jogador
                boolean withdrawn = plugin.getMongoDBManager().withdraw(
                        java.util.UUID.fromString(playerUUID), 
                        totalPrice, 
                        "Compra de " + quantity + "x " + item.getDisplayName()
                ).join();
                
                if (!withdrawn) {
                    future.complete(false);
                    return;
                }
                
                // Atualiza o estoque
                item.setStock(item.getStock() - quantity);
                
                // Atualiza no banco de dados
                Document filter = new Document("item_id", itemId);
                Document update = new Document("$inc", new Document("stock", -quantity));
                
                plugin.getMongoDBManager().getMarketItemsCollection().updateOne(filter, update);
                
                // Registra a transação
                Document transaction = new Document()
                        .append("uuid", playerUUID)
                        .append("item_id", itemId)
                        .append("type", "buy")
                        .append("quantity", quantity)
                        .append("price", item.getCurrentPrice())
                        .append("total", totalPrice)
                        .append("timestamp", System.currentTimeMillis());
                
                plugin.getMongoDBManager().getTransactionsCollection().insertOne(transaction);
                
                // Atualiza o preço do item
                updateItemPrice(item);
                
                future.complete(true);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao comprar item: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }

    /**
     * Vende um item para o shop
     * @param playerUUID UUID do jogador
     * @param itemId ID do item
     * @param quantity Quantidade a vender
     * @return CompletableFuture com o resultado da venda
     */
    public CompletableFuture<Boolean> sellItem(String playerUUID, String itemId, int quantity) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Verifica se o item existe
                if (!shopItems.containsKey(itemId)) {
                    future.complete(false);
                    return;
                }
                
                ShopItem item = shopItems.get(itemId);
                
                // Calcula o preço de venda (geralmente menor que o de compra)
                double sellPrice = item.getCurrentPrice() * 0.7; // 70% do preço de compra
                double totalPrice = sellPrice * quantity;
                
                // Adiciona o dinheiro ao jogador
                boolean deposited = plugin.getMongoDBManager().deposit(
                        java.util.UUID.fromString(playerUUID), 
                        totalPrice, 
                        "Venda de " + quantity + "x " + item.getDisplayName()
                ).join();
                
                if (!deposited) {
                    future.complete(false);
                    return;
                }
                
                // Atualiza o estoque
                item.setStock(item.getStock() + quantity);
                
                // Atualiza no banco de dados
                Document filter = new Document("item_id", itemId);
                Document update = new Document("$inc", new Document("stock", quantity));
                
                plugin.getMongoDBManager().getMarketItemsCollection().updateOne(filter, update);
                
                // Registra a transação
                Document transaction = new Document()
                        .append("uuid", playerUUID)
                        .append("item_id", itemId)
                        .append("type", "sell")
                        .append("quantity", quantity)
                        .append("price", sellPrice)
                        .append("total", totalPrice)
                        .append("timestamp", System.currentTimeMillis());
                
                plugin.getMongoDBManager().getTransactionsCollection().insertOne(transaction);
                
                // Atualiza o preço do item
                updateItemPrice(item);
                
                future.complete(true);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao vender item: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }

    /**
     * Adiciona um novo item ao shop
     * @param itemId ID do item (formato: MATERIAL ou namespace:key para itens de mods)
     * @param displayName Nome de exibição
     * @param category Categoria
     * @param basePrice Preço base
     * @param initialStock Estoque inicial
     * @return CompletableFuture com o resultado da adição
     */
    public CompletableFuture<Boolean> addItem(String itemId, String displayName, String category, double basePrice, int initialStock) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Verifica se o item já existe
                if (shopItems.containsKey(itemId)) {
                    future.complete(false);
                    return;
                }
                
                // Verifica se a categoria existe
                if (!categories.containsKey(category.toLowerCase())) {
                    future.complete(false);
                    return;
                }
                
                // Cria o ItemStack
                ItemStack itemStack;
                
                // Verifica se é um item de mod ou vanilla
                if (itemId.contains(":")) {
                    // Item de mod (formato namespace:key)
                    String[] parts = itemId.split(":");
                    String namespace = parts[0];
                    String key = parts[1];
                    
                    // Tenta obter o material do registro
                    NamespacedKey namespacedKey = new NamespacedKey(namespace, key);
                    Material material = Registry.MATERIAL.get(namespacedKey);
                    
                    if (material != null) {
                        itemStack = new ItemStack(material);
                    } else {
                        // Fallback para caso o item não seja encontrado
                        plugin.getLogger().warning("Item de mod não encontrado: " + itemId);
                        future.complete(false);
                        return;
                    }
                } else {
                    // Item vanilla
                    try {
                        Material material = Material.valueOf(itemId.toUpperCase());
                        itemStack = new ItemStack(material);
                    } catch (IllegalArgumentException e) {
                        plugin.getLogger().warning("Material inválido: " + itemId);
                        future.complete(false);
                        return;
                    }
                }
                
                // Configura o meta do item
                ItemMeta meta = itemStack.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName(displayName.replace("&", "§"));
                    meta.getPersistentDataContainer().set(itemIdKey, PersistentDataType.STRING, itemId);
                    itemStack.setItemMeta(meta);
                }
                
                // Cria o documento para o banco de dados
                Document itemDoc = new Document()
                        .append("item_id", itemId)
                        .append("display_name", displayName)
                        .append("category", category)
                        .append("base_price", basePrice)
                        .append("current_price", basePrice)
                        .append("stock", initialStock)
                        .append("last_update", System.currentTimeMillis());
                
                // Insere no banco de dados
                plugin.getMongoDBManager().getMarketItemsCollection().insertOne(itemDoc);
                
                // Cria o item do shop
                ShopItem shopItem = new ShopItem(itemId, displayName, itemStack, category, basePrice, basePrice, initialStock);
                shopItems.put(itemId, shopItem);
                
                // Adiciona à categoria
                categories.get(category.toLowerCase()).addItem(shopItem);
                
                future.complete(true);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao adicionar item ao shop: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }

    /**
     * Remove um item do shop
     * @param itemId ID do item
     * @return CompletableFuture com o resultado da remoção
     */
    public CompletableFuture<Boolean> removeItem(String itemId) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // Verifica se o item existe
                if (!shopItems.containsKey(itemId)) {
                    future.complete(false);
                    return;
                }
                
                ShopItem item = shopItems.get(itemId);
                
                // Remove do banco de dados
                Document filter = new Document("item_id", itemId);
                plugin.getMongoDBManager().getMarketItemsCollection().deleteOne(filter);
                
                // Remove da categoria
                if (categories.containsKey(item.getCategory().toLowerCase())) {
                    categories.get(item.getCategory().toLowerCase()).removeItem(item);
                }
                
                // Remove do mapa de itens
                shopItems.remove(itemId);
                
                future.complete(true);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Erro ao remover item do shop: " + e.getMessage(), e);
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }

    // Getters
    public Map<String, ShopItem> getShopItems() {
        return shopItems;
    }

    public Map<String, ShopCategory> getCategories() {
        return categories;
    }

    public ShopItem getItem(String itemId) {
        return shopItems.get(itemId);
    }

    public ShopCategory getCategory(String categoryName) {
        return categories.get(categoryName.toLowerCase());
    }
}
