package com.minecraft.economy.shop;

import org.bukkit.inventory.ItemStack;

/**
 * Representa um item disponível no shop
 */
public class ShopItem {
    
    private final String itemId;
    private final String displayName;
    private final ItemStack itemStack;
    private final String category;
    private final double basePrice;
    private double currentPrice;
    private int stock;
    
    public ShopItem(String itemId, String displayName, ItemStack itemStack, String category, 
                   double basePrice, double currentPrice, int stock) {
        this.itemId = itemId;
        this.displayName = displayName;
        this.itemStack = itemStack;
        this.category = category;
        this.basePrice = basePrice;
        this.currentPrice = currentPrice;
        this.stock = stock;
    }
    
    // Getters e Setters
    
    public String getItemId() {
        return itemId;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public ItemStack getItemStack() {
        return itemStack.clone(); // Retorna uma cópia para evitar modificações externas
    }
    
    public String getCategory() {
        return category;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
    
    public double getCurrentPrice() {
        return currentPrice;
    }
    
    public void setCurrentPrice(double currentPrice) {
        this.currentPrice = currentPrice;
    }
    
    public int getStock() {
        return stock;
    }
    
    public void setStock(int stock) {
        this.stock = stock;
    }
    
    /**
     * Cria uma cópia do ItemStack com a quantidade especificada
     * @param amount Quantidade desejada
     * @return ItemStack com a quantidade especificada
     */
    public ItemStack createItemStack(int amount) {
        ItemStack copy = itemStack.clone();
        copy.setAmount(amount);
        return copy;
    }
}
