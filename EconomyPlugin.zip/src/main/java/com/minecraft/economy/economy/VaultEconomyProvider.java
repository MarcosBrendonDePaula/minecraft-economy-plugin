package com.minecraft.economy.economy;

import com.minecraft.economy.core.EconomyPlugin;
import com.minecraft.economy.database.MongoDBManager;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bson.Document;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class VaultEconomyProvider implements Economy {

    private final EconomyPlugin plugin;
    private final MongoDBManager mongoDBManager;

    public VaultEconomyProvider(EconomyPlugin plugin) {
        this.plugin = plugin;
        this.mongoDBManager = plugin.getMongoDBManager();
    }

    @Override
    public boolean isEnabled() {
        return plugin.isEnabled();
    }

    @Override
    public String getName() {
        return "EconomyPlugin";
    }

    @Override
    public boolean hasBankSupport() {
        return false; // Não implementamos suporte a bancos neste plugin
    }

    @Override
    public int fractionalDigits() {
        return plugin.getConfig().getInt("economy.decimals", 2);
    }

    @Override
    public String format(double amount) {
        String format = plugin.getConfig().getString("economy.format", "%symbol%%amount%");
        String symbol = plugin.getConfig().getString("economy.currency_symbol", "$");
        
        // Formata o valor com o número correto de casas decimais
        String formattedAmount = String.format("%." + fractionalDigits() + "f", amount);
        
        return format.replace("%symbol%", symbol).replace("%amount%", formattedAmount);
    }

    @Override
    public String currencyNamePlural() {
        return plugin.getConfig().getString("economy.currency_plural", "Moedas");
    }

    @Override
    public String currencyNameSingular() {
        return plugin.getConfig().getString("economy.currency_singular", "Moeda");
    }

    @Override
    public boolean hasAccount(String playerName) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return hasAccount(player);
    }

    @Override
    public boolean hasAccount(OfflinePlayer player) {
        return mongoDBManager.hasAccount(player.getUniqueId()).join();
    }

    @Override
    public boolean hasAccount(String playerName, String worldName) {
        return hasAccount(playerName); // Não diferenciamos por mundo
    }

    @Override
    public boolean hasAccount(OfflinePlayer player, String worldName) {
        return hasAccount(player); // Não diferenciamos por mundo
    }

    @Override
    public double getBalance(String playerName) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return getBalance(player);
    }

    @Override
    public double getBalance(OfflinePlayer player) {
        return mongoDBManager.getBalance(player.getUniqueId()).join();
    }

    @Override
    public double getBalance(String playerName, String worldName) {
        return getBalance(playerName); // Não diferenciamos por mundo
    }

    @Override
    public double getBalance(OfflinePlayer player, String worldName) {
        return getBalance(player); // Não diferenciamos por mundo
    }

    @Override
    public boolean has(String playerName, double amount) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return has(player, amount);
    }

    @Override
    public boolean has(OfflinePlayer player, double amount) {
        return mongoDBManager.has(player.getUniqueId(), amount).join();
    }

    @Override
    public boolean has(String playerName, String worldName, double amount) {
        return has(playerName, amount); // Não diferenciamos por mundo
    }

    @Override
    public boolean has(OfflinePlayer player, String worldName, double amount) {
        return has(player, amount); // Não diferenciamos por mundo
    }

    @Override
    public EconomyResponse withdrawPlayer(String playerName, double amount) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return withdrawPlayer(player, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
        if (amount < 0) {
            return new EconomyResponse(0, getBalance(player), 
                    EconomyResponse.ResponseType.FAILURE, "Não é possível retirar um valor negativo");
        }
        
        UUID uuid = player.getUniqueId();
        boolean success = mongoDBManager.withdraw(uuid, amount, "Retirada via API").join();
        
        if (success) {
            return new EconomyResponse(amount, getBalance(player), 
                    EconomyResponse.ResponseType.SUCCESS, null);
        } else {
            return new EconomyResponse(0, getBalance(player), 
                    EconomyResponse.ResponseType.FAILURE, "Saldo insuficiente ou conta inexistente");
        }
    }

    @Override
    public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
        return withdrawPlayer(playerName, amount); // Não diferenciamos por mundo
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
        return withdrawPlayer(player, amount); // Não diferenciamos por mundo
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, double amount) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return depositPlayer(player, amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
        if (amount < 0) {
            return new EconomyResponse(0, getBalance(player), 
                    EconomyResponse.ResponseType.FAILURE, "Não é possível depositar um valor negativo");
        }
        
        UUID uuid = player.getUniqueId();
        
        // Cria a conta se não existir
        if (!hasAccount(player)) {
            createPlayerAccount(player);
        }
        
        boolean success = mongoDBManager.deposit(uuid, amount, "Depósito via API").join();
        
        if (success) {
            return new EconomyResponse(amount, getBalance(player), 
                    EconomyResponse.ResponseType.SUCCESS, null);
        } else {
            return new EconomyResponse(0, getBalance(player), 
                    EconomyResponse.ResponseType.FAILURE, "Falha ao depositar");
        }
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
        return depositPlayer(playerName, amount); // Não diferenciamos por mundo
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
        return depositPlayer(player, amount); // Não diferenciamos por mundo
    }

    @Override
    public EconomyResponse createBank(String name, String player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse createBank(String name, OfflinePlayer player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse deleteBank(String name) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse bankBalance(String name) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse bankHas(String name, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse bankWithdraw(String name, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse bankDeposit(String name, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse isBankOwner(String name, String playerName) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse isBankMember(String name, String playerName) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public EconomyResponse isBankMember(String name, OfflinePlayer player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, 
                "Este plugin não suporta bancos");
    }

    @Override
    public List<String> getBanks() {
        return new ArrayList<>(); // Lista vazia, não suportamos bancos
    }

    @Override
    public boolean createPlayerAccount(String playerName) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return createPlayerAccount(player);
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player) {
        if (hasAccount(player)) {
            return false; // Conta já existe
        }
        
        double initialBalance = plugin.getConfig().getDouble("economy.starting_balance", 1000.0);
        return mongoDBManager.createAccount(player.getUniqueId(), player.getName(), initialBalance).join();
    }

    @Override
    public boolean createPlayerAccount(String playerName, String worldName) {
        return createPlayerAccount(playerName); // Não diferenciamos por mundo
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player, String worldName) {
        return createPlayerAccount(player); // Não diferenciamos por mundo
    }
    
    /**
     * Aplica o decaimento por inatividade nas contas
     */
    public void applyInactivityDecay() {
        int daysThreshold = plugin.getConfig().getInt("taxes.inactivity_decay.days_threshold", 7);
        double dailyRate = plugin.getConfig().getDouble("taxes.inactivity_decay.daily_rate", 0.005);
        
        CompletableFuture<List<Document>> future = mongoDBManager.getInactivePlayers(daysThreshold);
        future.thenAccept(inactivePlayers -> {
            for (Document player : inactivePlayers) {
                String uuidString = player.getString("uuid");
                UUID uuid = UUID.fromString(uuidString);
                double balance = player.getDouble("balance");
                
                // Calcula o valor do decaimento
                double decayAmount = balance * dailyRate;
                
                if (decayAmount > 0) {
                    mongoDBManager.withdraw(uuid, decayAmount, "Decaimento por inatividade").join();
                    plugin.getLogger().info("Aplicado decaimento de " + decayAmount + " para jogador " + uuidString);
                }
            }
        });
    }
}
