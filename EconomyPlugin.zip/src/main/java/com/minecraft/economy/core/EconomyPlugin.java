package com.minecraft.economy.core;

import com.minecraft.economy.database.MongoDBManager;
import com.minecraft.economy.economy.VaultEconomyProvider;
import com.minecraft.economy.commands.MoneyCommand;
import com.minecraft.economy.commands.EcoAdminCommand;
import com.minecraft.economy.commands.ShopCommand;
import com.minecraft.economy.commands.TaxCommand;
import com.minecraft.economy.listeners.PlayerListener;
import com.minecraft.economy.shop.ShopManager;
import lombok.Getter;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

public class EconomyPlugin extends JavaPlugin {

    @Getter
    private static EconomyPlugin instance;
    
    @Getter
    private MongoDBManager mongoDBManager;
    
    @Getter
    private VaultEconomyProvider economyProvider;
    
    @Getter
    private ShopManager shopManager;
    
    @Getter
    private ConfigManager configManager;

    @Override
    public void onEnable() {
        // Inicializa a instância
        instance = this;
        
        // Carrega a configuração
        saveDefaultConfig();
        configManager = new ConfigManager(this);
        
        // Inicializa o gerenciador do MongoDB
        mongoDBManager = new MongoDBManager(this);
        if (!mongoDBManager.connect()) {
            getLogger().severe("Falha ao conectar ao MongoDB! Desativando plugin...");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // Inicializa o provedor de economia para o Vault
        economyProvider = new VaultEconomyProvider(this);
        
        // Registra o provedor de economia no Vault
        if (getServer().getPluginManager().getPlugin("Vault") != null) {
            getServer().getServicesManager().register(
                Economy.class,
                economyProvider,
                this,
                ServicePriority.Highest
            );
            getLogger().info("Integração com Vault concluída com sucesso!");
        } else {
            getLogger().severe("Vault não encontrado! Desativando plugin...");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // Inicializa o gerenciador de shop
        shopManager = new ShopManager(this);
        
        // Registra comandos
        getCommand("money").setExecutor(new MoneyCommand(this));
        getCommand("eco").setExecutor(new EcoAdminCommand(this));
        getCommand("shop").setExecutor(new ShopCommand(this));
        getCommand("tax").setExecutor(new TaxCommand(this));
        
        // Registra listeners
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        
        // Inicia tarefas agendadas
        startScheduledTasks();
        
        getLogger().info("EconomyPlugin ativado com sucesso!");
    }

    @Override
    public void onDisable() {
        // Fecha a conexão com o MongoDB
        if (mongoDBManager != null) {
            mongoDBManager.disconnect();
        }
        
        // Cancela todas as tarefas agendadas
        Bukkit.getScheduler().cancelTasks(this);
        
        getLogger().info("EconomyPlugin desativado com sucesso!");
    }
    
    private void startScheduledTasks() {
        // Tarefa para atualizar preços do shop
        int updateInterval = getConfig().getInt("shop.update_interval", 30) * 1200; // Converte minutos para ticks
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
            shopManager.updateAllPrices();
            getLogger().info("Preços do shop atualizados com sucesso!");
        }, updateInterval, updateInterval);
        
        // Tarefa para aplicar decaimento por inatividade
        if (getConfig().getBoolean("taxes.inactivity_decay.enabled", true)) {
            Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
                economyProvider.applyInactivityDecay();
                getLogger().info("Decaimento por inatividade aplicado com sucesso!");
            }, 72000, 72000); // A cada 1 hora (72000 ticks)
        }
    }
}
