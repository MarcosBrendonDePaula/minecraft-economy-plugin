package com.minecraft.economy.core;

import com.minecraft.economy.core.EconomyPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

public class ConfigManager {

    private final EconomyPlugin plugin;
    private FileConfiguration config;
    private File configFile;

    public ConfigManager(EconomyPlugin plugin) {
        this.plugin = plugin;
        this.config = plugin.getConfig();
        this.configFile = new File(plugin.getDataFolder(), "config.yml");
        
        // Salva a configuração padrão se não existir
        plugin.saveDefaultConfig();
        
        // Carrega a configuração
        reloadConfig();
    }

    /**
     * Recarrega a configuração do arquivo
     */
    public void reloadConfig() {
        try {
            config = YamlConfiguration.loadConfiguration(configFile);
            plugin.getLogger().info("Configuração carregada com sucesso!");
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Erro ao carregar configuração: " + e.getMessage(), e);
        }
    }

    /**
     * Salva a configuração no arquivo
     */
    public void saveConfig() {
        try {
            config.save(configFile);
            plugin.getLogger().info("Configuração salva com sucesso!");
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Erro ao salvar configuração: " + e.getMessage(), e);
        }
    }

    /**
     * Obtém a configuração
     * @return Configuração atual
     */
    public FileConfiguration getConfig() {
        return config;
    }
}
