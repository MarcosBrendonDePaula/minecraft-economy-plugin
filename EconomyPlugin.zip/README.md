# Guia de Instalação e Uso - EconomyPlugin

## Requisitos
- Servidor Minecraft 1.20.1 (Paper/Spigot recomendado)
- Plugin Vault instalado
- MongoDB instalado e configurado
- Java 17 ou superior

## Instalação

1. Certifique-se de que o MongoDB está instalado e rodando em seu servidor ou máquina
2. Instale o plugin Vault em seu servidor Minecraft
3. Coloque o arquivo `EconomyPlugin.jar` na pasta `plugins` do seu servidor
4. Inicie ou reinicie o servidor
5. Configure o arquivo `config.yml` gerado na pasta `plugins/EconomyPlugin`

## Configuração

### MongoDB
Por padrão, o plugin tentará se conectar ao MongoDB em `localhost:27017`. Se seu MongoDB estiver em outro local ou precisar de autenticação, edite as seguintes configurações no arquivo `config.yml`:

```yaml
mongodb:
  uri: 'mongodb://localhost:27017'
  database: 'minecraft_economy'
  auth:
    enabled: false
    username: ''
    password: ''
    authSource: 'admin'
```

### Economia
Você pode configurar os valores iniciais da economia:

```yaml
economy:
  starting_balance: 1000.0
  currency_singular: 'Moeda'
  currency_plural: 'Moedas'
  currency_symbol: '$'
```

### Impostos
O sistema de impostos pode ser configurado:

```yaml
taxes:
  transaction_tax: 0.02  # 2% de imposto em transações
  wealth_tax:
    enabled: true
    threshold: 100000.0  # Valor a partir do qual o imposto de riqueza é aplicado
    rate: 0.01  # 1% de imposto sobre riqueza acima do threshold
  inactivity_decay:
    enabled: true
    days_threshold: 7  # Dias de inatividade antes de começar a decair
    daily_rate: 0.005  # 0.5% de decaimento diário após o threshold
```

### Shop
O sistema de shop e preços dinâmicos pode ser configurado:

```yaml
shop:
  update_interval: 30  # Intervalo em minutos para atualização de preços
  price_limits:
    min_multiplier: 0.1  # Preço mínimo = preço base * min_multiplier
    max_multiplier: 10.0  # Preço máximo = preço base * max_multiplier
  algorithm:
    scarcity_weight: 0.6  # Peso do fator de escassez no cálculo
    demand_weight: 0.4  # Peso do fator de demanda no cálculo
```

## Comandos

### Comandos para Jogadores
- `/money` - Ver seu saldo
- `/money <jogador>` - Ver o saldo de outro jogador
- `/money pay <jogador> <quantia>` - Transferir dinheiro para outro jogador
- `/money top` - Ver o ranking de jogadores mais ricos
- `/shop` - Abrir a interface do shop

### Comandos Administrativos
- `/eco give <jogador> <quantia>` - Dar dinheiro a um jogador
- `/eco take <jogador> <quantia>` - Remover dinheiro de um jogador
- `/eco set <jogador> <quantia>` - Definir o saldo de um jogador
- `/eco reset <jogador>` - Resetar a conta de um jogador
- `/tax set <tipo> <valor>` - Definir uma taxa de imposto (tipos: transaction, wealth, inactivity)
- `/tax enable <tipo>` - Ativar um tipo de imposto (tipos: wealth, inactivity)
- `/tax disable <tipo>` - Desativar um tipo de imposto (tipos: wealth, inactivity)
- `/tax apply <tipo>` - Aplicar um imposto imediatamente (tipos: wealth, inactivity)
- `/tax info` - Ver informações sobre os impostos atuais

## Permissões
- `economy.shop.use` - Permite usar o shop
- `economy.money.pay` - Permite transferir dinheiro
- `economy.money.top` - Permite ver o ranking de jogadores mais ricos
- `economy.admin` - Permite acesso a comandos administrativos

## Adicionando Itens de Mods ao Shop
O plugin suporta itens de mods no shop. Para adicionar um item de mod, você precisa conhecer seu ID no formato `namespace:key`.

Exemplo: Para adicionar um item do mod "examplemod" com o ID "special_item", você usaria:
```
/shop additem examplemod:special_item "Item Especial" Recursos 100.0 10
```

Onde:
- `examplemod:special_item` é o ID do item
- `"Item Especial"` é o nome de exibição
- `Recursos` é a categoria
- `100.0` é o preço base
- `10` é o estoque inicial

## Configurações no MongoDB
Algumas configurações do plugin são armazenadas no MongoDB, permitindo alterações em tempo real sem reiniciar o servidor. Estas configurações incluem:

- Taxas de impostos
- Parâmetros do algoritmo de preços
- Limites de preços

Estas configurações podem ser alteradas através dos comandos administrativos ou diretamente no banco de dados.

## Solução de Problemas

### Problemas de Conexão com MongoDB
Se o plugin não conseguir se conectar ao MongoDB, verifique:
1. Se o MongoDB está rodando
2. Se as configurações de conexão estão corretas
3. Se há algum firewall bloqueando a conexão
4. Os logs do servidor para mensagens de erro específicas

### Compatibilidade com Outros Plugins
Este plugin foi projetado para ser compatível com outros plugins que usam o Vault. Se houver conflitos:
1. Certifique-se de que o EconomyPlugin está registrado como o provedor de economia principal
2. Verifique se não há outros plugins tentando registrar-se como provedores de economia
3. Consulte os logs do servidor para mensagens de erro

### Suporte a Mods
Se estiver tendo problemas com itens de mods no shop:
1. Verifique se o ID do item está correto (namespace:key)
2. Certifique-se de que o mod está carregado no servidor
3. Alguns mods podem requerer configurações adicionais para integração
